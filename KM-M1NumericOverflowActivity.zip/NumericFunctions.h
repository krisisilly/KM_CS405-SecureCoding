#pragma once
#include <iostream>
#include <limits>

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // checks overflow. If adding increment exceeds max value for type T
        if (std::numeric_limits<T>::max() - result < increment)
        {
            std::cout << "\t\t[!] Overflow at " << i << std::endl;
            return std::numeric_limits<T>::max(); // signals overflow by returning sentinel value
        }

        result += increment; // safe to add.
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // checks overflow for decrement. If subtracting decrement would fall below min value. 
        if (result - std::numeric_limits<T>::lowest() < decrement)
        {
            std::cout << "\t\t[!] Underflow at " << i << std::endl;
            return std::numeric_limits<T>::lowest(); // signals underflow by returning sentinel value. 
        }

        result -= decrement; // safe to subtract.
    }

    return result;
}

